<?php
/*
Template Name: 日志存档
*/
?>
<?php get_header(); ?>
            <?php div_cotent(); ?> 
            		<div id="index" class="bs uk-text-break">
						    <h1 class="h4"><?php the_title(); ?></h1>
            			<div id="list">
        					<p class="date"><strong><?php bloginfo('name'); ?></strong>目前共有文章：  <?php echo $hacklog_archives->PostCount();?>篇  </p>
    						<?php echo $hacklog_archives->PostList();?>
						</div>
            		</div>
				<?php if(!of_get('is_widget')){ ?>  
                <div class="ft uk-visible-small">
                        <p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
                </div>
                <?php } ?>
            </div>
            <?php widget_Qzhai('page')?> 
            <?php if(of_get('is_widget')){ ?>  
                <div class="ft uk-visible-small">
                        <p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
                </div>
            <?php } ?>
            </div>
<?php get_footer(); ?>
