<?php get_header(); ?>
            <?php div_cotent(); ?> 
            		<div id="index" class="bs uk-text-break">
            			<article id="article" class="uk-article">
						    <h1 class="uk-article-title"><?php the_title(); ?></h1>
						    <?php 
								while ( have_posts() ) : the_post();
	
								the_content();
			
								endwhile;
							?>
						</article>
						    <?php if ( comments_open() || get_comments_number() ) {?>
							<div id="qzhai_comments">
								<?php comments_template(); ?>
							</div>
							<?php }?>
            		</div>
				<?php if(!of_get('is_widget')){ ?> 	
				<div class="ft uk-visible-small">
	        		<p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
		        </div>
		        <?php } ?>
            </div>
            <?php widget_Qzhai('page')?> 
            <?php if(of_get('is_widget')){ ?> 	
			<div class="ft uk-visible-small">
        		<p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
	        </div>
	        <?php } ?>
        </div>
<?php get_footer(); ?>
