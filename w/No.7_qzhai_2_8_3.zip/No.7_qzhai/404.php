<?php get_header(); ?>
            <?php div_cotent(); ?> 
            		<div id="index" class="bs">
            			<article id="article" class="uk-article">
					       <?php 
                                          if(of_get('diy_404')){
                                                echo of_get('diy_404');
                                          }else{
                                                echo '<p class="_404">没发现什么...</p>';
                                          }
                                    ?>
					</article>	   
            		</div>
				<?php if(!of_get('is_widget')){ ?> 	
				<div class="ft uk-visible-small">
	        		<p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
		        </div>
		        <?php } ?>
            </div>
            <?php widget_Qzhai('page')?> 
            <?php if(of_get('is_widget')){ ?> 	
			<div class="ft uk-visible-small">
        		<p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
	        </div>
	        <?php } ?>
        </div>
<?php get_footer(); ?>
