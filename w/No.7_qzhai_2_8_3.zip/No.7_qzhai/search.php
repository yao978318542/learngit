<?php get_header(); ?>
            <?php div_cotent(); ?> 
      		<div id="index" class="bs uk-text-break">
      			<h4><?php the_search_query(); ?> - 搜索结果</h4>
      			<div id="list">
						<?php index_loop();?>
      			</div>
      		</div>
				<ul class="uk-pagination">
				    <?php par_pagenavi(); ?>
				</ul>
			<?php if(!of_get('is_widget')){ ?>    
                  <div class="ft uk-visible-small">
                        <p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
                  </div>
                  <?php } ?>
            </div>
            <?php widget_Qzhai('page')?> 
            <?php if(of_get('is_widget')){ ?>  
                  <div class="ft uk-visible-small">
                        <p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
                  </div>
            <?php } ?>
            </div>
<?php get_footer(); ?>
