<?php
/*
Template Name: 友情链接
*/
?>
<?php get_header(); ?>
            <?php div_cotent(); ?> 
            		<div id="index" class="bs uk-text-break">
						    <h1 class="h4"><?php the_title(); ?></h1>
            			<div id="list" class="index_link">
        					<?php
                                while ( have_posts() ) : the_post();
    
                                the_content();
            
                                endwhile;
                                

                               wp_nav_menu(
                                array(
                                    'theme_location'=>'link',
                                    'menu_id'=>'link_l',
                                    'menu_class'=>'uk-nav',
                                    'container'=>'div',
                                    'walker' => new qzhai_menu_link(),
                                    'items_wrap' => '<div id="%1$s" class="%2$s" data-uk-nav ><ul class="uk-grid  uk-grid-width-1-2 uk-grid-medium">%3$s</ul></div>',
                                    'depth'=>'2',
                                    ));
                            ?>

						</div>
                        <?php if ( comments_open() || get_comments_number() ) {?>
                            <div id="qzhai_comments">
                                <?php comments_template(); ?>
                            </div>
                            <?php }?>
            		</div>
				<?php if(!of_get('is_widget')){ ?>  
                <div class="ft uk-visible-small">
                        <p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
                </div>
                <?php } ?>
            </div>
            <?php widget_Qzhai('page')?> 
            <?php if(of_get('is_widget')){ ?>  
                <div class="ft uk-visible-small">
                        <p><?php /* 请勿删除此行代码！擅自删除后果自负！ */echo of_get('footer');getfoot('foot');?></p>
                </div>
            <?php } ?>
            </div>
            <script type="text/javascript">
                
    		</script>

<?php get_footer(); ?>
